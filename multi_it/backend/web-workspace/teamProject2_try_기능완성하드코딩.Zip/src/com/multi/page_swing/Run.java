package com.multi.page_swing;

public class Run {
    public static void main(String[] args) {
        FirstPage fitstPage = new FirstPage();
//        Game g = new Game();
//        System.out.println("점수" + g.Meun(1, 1));//레벨을 받고 점수 출력
    }

}
