package com.multi.gameProject.generalUsers.app;

import com.multi.gameProject.generalUsers.view.generalUser.GeneralUserBeforeLoginPage;

public class GeneralUserRun {
	
	public static void main(String[] args) {
		
		GeneralUserBeforeLoginPage firstPage = new GeneralUserBeforeLoginPage();
		
	
		
		
	}
	
	
}
