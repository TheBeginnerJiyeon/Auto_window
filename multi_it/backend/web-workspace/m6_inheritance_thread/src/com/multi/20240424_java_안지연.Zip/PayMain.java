package com.multi.homework;

public class PayMain {
	public static void main(String[] args) {
		
		View v = new View();
		v.windowPop();
		
	
		
	}
}
